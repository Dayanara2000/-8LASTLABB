/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication3 {
        
        main(String[]args){
		Numero a = new Numero();
		a.obtenerDatos();
		a.mayorMenor();
		System.out.println(a.toString()); 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    }
    
}
